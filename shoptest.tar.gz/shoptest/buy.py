#!/usr/bin/python
#-*- coding:utf-8 -*-

import mysql.connector as con
import pandas as pd
import json,random


def buy(post_str):
	msg=""
	jsonStr=""
	l=[]
	json_dic=json.loads(post_str)
	id=int(json_dic["id"])
	sid=int(json_dic["sid"])
	num=int(json_dic["num"])
        conn = con.connect(user='root',password='root',database='test1',use_unicode=True)
        cursor =conn.cursor()
	df=pd.read_excel('./shop/blackmarket_items.xls')
	res=int(sid)-100000
        result=df[res+1:res+2]
	str1=str(result.values.tolist()).split(" ")
        str2=str1[3][2:-3].split(",")
	cursor.execute("select num from t_props where rid=%s and cid=%s",(id,sid,))
        result1=cursor.fetchone()
	if not result1:
		cursor.execute("select num from t_props where rid=%s and cid=%s",(id,str2[0],))
		result=cursor.fetchone()
		if result[0]-(int(str2[1])*num)>=0:
			num1=result[0]
			num1-=int(str2[1])*num
			cursor.execute("update t_props set num=%s where rid=%s and cid=%s",(num1,id,str2[0],))
			cursor.execute("insert into t_props value(%s,%s,%s)",(id,sid,num,))
			conn.commit()
			msg=u"购买成功！"
		else:
			msg=u"余额不足，购买失败！"
	else:
	 	if result1[0]==int(str1[8][:-1]):
			msg=u"超过最大购买数量"
			cursor.execute("select rid,s1,n1,s2,n2,s3,n3,s4,n4,s5,n5,s6,n6 from t_blackmarket where rid=%s",(id,))
        		result=cursor.fetchone()
			l=list(result)
			for i in range(1,len(l),2):
				if int(l[i])==sid:
					index=i/2
					df1=pd.read_excel('./shop/blackmarket_pos.xls')
					key=[]
                        		value=[]
                        		list1=str(list(df1.iloc[:,2].values)[2:][index]).split(";")
                        		for j in range(len(list1)-1):
                                		str1=list1[j].split(",")
                                		key.append(int(str1[0]))
                                		value.append(int(str1[1]))
                        		dic=dict(zip(key,value))
                        		total = sum(dic.values())
                        		rad = random.randint(1,total)
                        		cur_total = 0
                        		res = ""
                        		for k, v in dic.items():
                                		cur_total += v
                                		if rad<= cur_total:
                                        		res = k 
                                        		break
                        		res=res-100000
                        		result=df[res+1:res+2]
                        		str1=str(result.values.tolist()).split(" ")
					cursor.execute("select vip,level from t_role where id =%s",(id,)) 
					result=cursor.fetchone()
                        		if result[0]>=int(str1[9][:-1]) and result[1]>=int(str1[10][:-1]):
						l[i]=int(str1[0][2:-1])
						l[i+1]=int(str1[7][:-1])
					cursor.execute("delete from t_blackmarket where rid=%s",(id,))
					conn.commit()
					cursor.execute("insert into t_blackmarket value(null,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",l)
	               			conn.commit()
		else:
			cursor.execute("select num from t_props where rid=%s and cid=%s",(id,str2[0],))
	                result=cursor.fetchone()
			if result[0]>=(int(str2[1])*num):
                        	num1=result[0]
                        	num1-=int(str2[1])*num
                        	cursor.execute("update t_props set num=%s where rid=%s and cid=%s",(num1,id,str2[0],))
				conn.commit()
				cursor.execute("update t_props set num=num+%s where rid=%s and cid=%s",(num,id,sid,))
				conn.commit()
                        	msg=u"购买成功！"
                	else:       
                        	msg=u"余额不足，购买失败！"
	result_msg={"msg":msg}
	return json.dumps(result_msg,ensure_ascii=False)
#if __name__=="__main__":
#	dic={"id":2,"sid":100039,"num":1}
#	json_dic=json.dumps(dic)
#	retultMsg=buy(json_dic)
#	print json.loads(retultMsg)["msg"]
