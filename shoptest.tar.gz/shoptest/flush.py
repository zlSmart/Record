#!/usr/bin/python
#-*- coding:utf-8 -*-

import mysql.connector as con
import pandas as pd
import json,random

def flush(post_str):
	jsonStr=""
	dic_str=json.loads(post_str)
        id=int(dic_str["id"])
        vip=int(dic_str["vip"])
        level=int(dic_str["level"])
        conn = con.connect(user='root',password='root',database='test1',use_unicode=True)
        cursor =conn.cursor()
        cursor.execute("delete from t_blackmarket where rid=%s",(id,))
        conn.commit()
	insertList=[]
	insertList.append(id)
	df=pd.read_excel('./shop/blackmarket_pos.xls')
	df1=pd.read_excel('./shop/blackmarket_items.xls')
	flag=True
	i=0
	while flag:
		key=[]
		value=[]
		list1=str(list(df.iloc[:,2].values)[2:][i]).split(";")
		for j in range(len(list1)-1):
			str1=list1[j].split(",")
			key.append(int(str1[0]))
			value.append(int(str1[1]))
		dic=dict(zip(key,value))
		total = sum(dic.values())
		rad = random.randint(1,total)
		cur_total = 0
		res = ""
		for k, v in dic.items():
			cur_total += v
			if rad<= cur_total:
				res = k 
				break
		res=res-100000
		result=df1[res+1:res+2]
		str2=str(result.values.tolist()).split(" ")
		if vip>=int(str2[9][:-1]) and level>=int(str2[10][:-1]):
			insertList.append(int(str2[0][2:-1]))
			insertList.append(int(str2[7][:-1]))
			i=i+1
		if i==6:
                	flag=False
                        break
	cursor.execute("insert into t_blackmarket value(null,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",insertList)
	conn.commit()
	msg="刷新成功！"
	result_msg={"msg":msg,"result":insertList}
        return json.dumps(result_msg,ensure_ascii=False) 

if __name__=="__main__":
	dic={"id":1,"vip":1,"level":30}
        dic_json=json.dumps(dic)
        result_json=flush(dic_json)
	print result_json
