#!/usr/bin/python
#-*- coding:utf-8 -*-

from flask import Flask
from flask import request
from flask import render_template
import query,buy,flush,json

app=Flask(__name__)

@app.route('/shoprefresh')
def flushshop():
	id=request.args.get("id")
	vip=request.args.get("vip")
	level=request.args.get("level")
	dic={"id":id,"vip":vip,"level":level}
        dic_json=json.dumps(dic)
        result_json=flush.flush(dic_json)
        return result_json

@app.route('/shopexchange')
def buything():
	id=request.args.get("id")
        sid=request.args.get("sid")
        num=request.args.get("num")
	retultMsg=""
	if int(sid)-100000>0 and int(sid)-100000<82:
		dic={"id":id,"sid":sid,"num":num}
	        json_dic=json.dumps(dic)
		retultMsg=buy.buy(json_dic)
	else:
		retultMsg=json.dumps({"msg":"该道具不存在！"},ensure_ascii=False)
        return retultMsg

@app.route('/shopquery')
def shopquery():
	id=request.args.get("id")
	vip=request.args.get("vip")
	level=request.args.get("level")
	dic={"id":id,"vip":vip,"level":level}
        dic_json=json.dumps(dic)
        result=query.query(dic_json)
	return result

if __name__=="__main___":
        app.run()
