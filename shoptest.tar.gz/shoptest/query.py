#!/usr/bin/python
#-*-coding:utf-8-*-

import mysql.connector as con
import pandas as pd
import random,json
import cgi, cgitb

def query(post_str):
        jsonStr=""
        msg=""
	df=pd.read_excel('./shop/blackmarket_pos.xls')
	df1=pd.read_excel('./shop/blackmarket_items.xls')
        dic_str=json.loads(post_str)
        id=int(dic_str["id"])
        vip=int(dic_str["vip"])
        level=int(dic_str["level"])
        conn = con.connect(user='root',password='root',database='test1',use_unicode=True)
        cursor =conn.cursor()
        cursor.execute("select rid,s1,n1,s2,n2,s3,n3,s4,n4,s5,n5,s6,n6 from t_blackmarket where rid=%s",(1,))
        result=cursor.fetchone()
        if not result:
		insertList=[]
		insertList.append(id)
		flag=True
		i=0
		while flag:
			key=[]
			value=[]
			list1=str(list(df.iloc[:,2].values)[2:][i]).split(";")
			for i in range(len(list1)-1):
				str1=list1[i].split(",")
				key.append(int(str1[0]))
				value.append(int(str1[1]))
			dic=dict(zip(key,value))
			total = sum(dic.values())
			rad = random.randint(1,total)
			cur_total = 0
			res = ""
			for k, v in dic.items():
				cur_total += v
				if rad<= cur_total:
					res = k 
					break
			res=res-100000
			result=df1[res+1:res+2]
			str1=str(result.values.tolist()).split(" ")
			if vip>=int(str1[9][:-1]) and level>=int(str1[10][:-1]):
				insertList.append(str1[0][2:-1])
				insertList.append(str1[7][:-1])
				i=i+1
			if i==6:
				flag=False
				break
		cursor.execute("insert into t_blackmarket value(null,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",insertList)
                conn.commit()
                msg=tuple(insertList)
	else:
		msg=result
        jsonStr=json.dumps({"msg":msg},ensure_ascii=False)
        return jsonStr               	

if __name__=="__main__":
	dic={"id":3,"vip":1,"level":30}
        dic_json=json.dumps(dic)
        result_json=query(dic_json)
	print result_json
