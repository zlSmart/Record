#!/usr/bin/python
#-*-coding:utf-8-*-

import mysql.connector as con
import pandas as pd
import random,json
import cgi, cgitb

def query(post_str):
	jsonStr=""
	msg=""
	dic_str=json.loads(post_str)
	id=int(dic_str["id"])
	vip=int(dic_str["vip"])
	level=int(dic_str["level"])
	conn = con.connect(user='root',password='root',database='test1',use_unicode=True)
        cursor =conn.cursor()
	cursor.execute("select rid,s1,n1,s2,n2,s3,n3,s4,n4,s5,n5,s6,n6 from t_blackmarket where rid=%s",(id,))
	result=cursor.fetchone()
	if not result:
		insertList=[]
		insertList.append(id)
		df=pd.read_excel('./shop/blackmarket_items.xls')
		list1=list(df.iloc[:,0].values)
		list2=list(df.iloc[:,11].values)
		print list1,list2
		dic=dict(zip(list1[3:],list2[3:]))
		total = sum(dic.values())
		flag=True
		index=0
		while flag:
			print '-------------------------------------'
			rad = random.randint(1,total)
			cur_total = 0
			res = ""
			for k, v in dic.items():
				cur_total += v
				if rad<= cur_total:
					res = k 
					break
			res=res-100000
			result=df[res:res+1]
			str1=str(result.values.tolist()).split(" ")
			print str1[0][2:-1],str1[7][:-1],str1[9][:-1],str1[10][:-1]
			if vip>=int(str1[9][:-1]) and level>=int(str1[10][:-1]):
				if str1[0][2:-1] in insertList:
					continue
				insertList.append(str1[0][2:-1])
				insertList.append(str1[7][:-1])
				index+=1
			if index==6:
				flag=False
			print '-------------------------------------'
			print len(insertList)
#		print insertList
		cursor.execute("insert into t_blackmarket value(null,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",insertList)
		conn.commit()
		msg=tuple(insertList)
	else:
		msg=result
	jsonStr=json.dumps({"msg":msg},ensure_ascii=False)
	return jsonStr

if __name__=="__main__":
	dic={"id":1,"vip":1,"level":30}
	dic_json=json.dumps(dic)
	result_json=query(dic_json)
	print json.loads(result_json)
