#!/usr/bin/python
#-*- coding:utf-8 -*-

import json,random
from oper import conn,cursor,df,df1
import query


def buy(post_str):
	msg=""
	jsonStr=""
	l=[]
	json_dic=json.loads(post_str)
	id=int(json_dic["id"])
	sid=int(json_dic["sid"])
	num=int(json_dic["num"])
	res_index=query.get_index(sid)
        str2=res_index[4][:-1].split(",")
	cursor.execute("select num from t_props where rid=%s and cid=%s",(id,sid,))
        result1=cursor.fetchone()
	if not result1:
		cursor.execute("select num from t_props where rid=%s and cid=%s",(id,str2[0],))
		result=cursor.fetchone()
		if result[0]-(int(str2[1])*num)>=0:
			num1=result[0]
			num1-=int(str2[1])*num
			cursor.execute("update t_props set num=%s where rid=%s and cid=%s",(num1,id,str2[0],))
			cursor.execute("insert into t_props value(%s,%s,%s)",(id,sid,num,))
			conn.commit()
			msg=u"购买成功！"
		else:
			msg=u"余额不足，购买失败！"
	else:
	 	if result1[0]==res_index[1]:
			msg=u"超过最大购买数量"
			cursor.execute("select rid,s1,n1,s2,n2,s3,n3,s4,n4,s5,n5,s6,n6 from t_blackmarket where rid=%s",(id,))
        		result=cursor.fetchone()
			l=list(result)
			for i in range(1,len(l),2):
				if int(l[i])==sid:
					index=i/2
					key=[]
                        		value=[]
					list1=str(df.iloc[index:index+1,2].values[0]).split(";")[:-1]
                        		for j in range(len(list1)-1):
                                		str1=list1[j].split(",")
                                		key.append(int(str1[0]))
                                		value.append(int(str1[1]))
                        		dic=dict(zip(key,value))
					print dic
                        		total = sum(dic.values())
                        		rad = random.randint(1,total)
                        		cur_total = 0
                        		res = ""
                        		for k, v in dic.items():
                                		cur_total += v
                                		if rad<= cur_total:
                                        		res = k 
                                        		break
                        		res=res-100000
					res_index=query.get_index(res)
					cursor.execute("select vip,level from t_role where id =%s",(id,)) 
					result=cursor.fetchone()
                        		if result[0]>=res_index[2] and result[1]>=res_index[3]:
						l[i]=res_index[0]
						l[i+1]=res_index[1]
					cursor.execute("delete from t_blackmarket where rid=%s",(id,))
					conn.commit()
					cursor.execute("insert into t_blackmarket value(null,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",l)
	               			conn.commit()
		else:
			cursor.execute("select num from t_props where rid=%s and cid=%s",(id,str2[0],))
	                result=cursor.fetchone()
			if result[0]>=(int(str2[1])*num):
                        	num1=result[0]
                        	num1-=int(str2[1])*num
                        	cursor.execute("update t_props set num=%s where rid=%s and cid=%s",(num1,id,str2[0],))
				conn.commit()
				cursor.execute("update t_props set num=num+%s where rid=%s and cid=%s",(num,id,sid,))
				conn.commit()
                        	msg=u"购买成功！"
                	else:       
                        	msg=u"余额不足，购买失败！"
	result_msg={"msg":msg}
	return json.dumps(result_msg,ensure_ascii=False)
