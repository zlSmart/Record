#!/usr/bin/python
#-*- coding:utf-8 -*-

DB_USER="root"
DB_PASSWORD="root"
DB_DATABASE="test1"
USE_UNICODE=True
