#!/usr/bin/python
#-*- coding:utf-8 -*-

import json,random
from oper import conn,cursor,df,df1
import query

def flush(post_str):
	jsonStr=""
	dic_str=json.loads(post_str)
        id=int(dic_str["id"])
        cursor.execute("delete from t_blackmarket where rid=%s",(id,))
        conn.commit()
	insertList=query.random_shop(id)
	if not len(insertList):
		result_msg={"msg":"此用户不存在！"}
	else:
		result_msg={"msg":"刷新成功","result":insertList}
        return json.dumps(result_msg,ensure_ascii=False) 

