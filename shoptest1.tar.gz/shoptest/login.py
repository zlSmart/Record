#!/usr/bin/python
#-*- coding:utf-8 -*-

from flask import Flask
from flask import request
from flask import render_template
import query,buy,flush,json
import user_manager

app=Flask(__name__)

@app.route('/shoprefresh')
def flushshop():
	id=request.args.get("id")
	dic={"id":id}
        dic_json=json.dumps(dic)
        result_json=flush.flush(dic_json)
        return result_json

@app.route('/shopexchange')
def buything():
	id=request.args.get("id")
        sid=request.args.get("sid")
        num=request.args.get("num")
	retultMsg=""
	if int(sid)-100000>0 and int(sid)-100000<82:
		dic={"id":id,"sid":sid,"num":num}
	        json_dic=json.dumps(dic)
		retultMsg=buy.buy(json_dic)
	else:
		retultMsg=json.dumps({"msg":"该道具不存在！"},ensure_ascii=False)
        return retultMsg

@app.route('/shopquery')
def shopquery():
	id=request.args.get("id")
	dic={"id":id}
        dic_json=json.dumps(dic)
        result=query.query(dic_json)
	return result

@app.route("/")
def index():
	return render_template("index.html")

@app.route("/login",methods = ['GET', 'POST'])
def login():
	if request.method == "POST":
        	username = request.form.get('username')
        	password = request.form.get('password')
		msg=user_manager.login(username,password)
		return json.dumps({"msg":msg},ensure_ascii=False)
    	else:
        	return render_template("login.html")

@app.route("/registe",methods = ['GET', 'POST'])
def registe():
	if request.method == "POST":
                username = request.form.get('username')
                password = request.form.get('password')
		repassword = request.form.get('repassword')
		if password==repassword:
			msg=user_manager.register(username,password)
                	return "<h1>%s</h1>" %msg
		else:
			return "<h1>两次输入密码不一致！</h1>"
        else:
		return render_template("register.html")
if __name__=="__main___":
        app.run(debug=True)
