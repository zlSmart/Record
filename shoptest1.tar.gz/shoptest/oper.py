#!/usr/bin/python
#-*- coding:utf-8 -*-

import mysql.connector as con
import pandas as pd
import config

conn = con.connect(user=config.DB_USER,password=config.DB_PASSWORD,database=config.DB_DATABASE,use_unicode=True)
cursor =conn.cursor()
df=pd.read_excel('./shop/blackmarket_pos.xls')
df1=pd.read_excel('./shop/blackmarket_items.xls')

