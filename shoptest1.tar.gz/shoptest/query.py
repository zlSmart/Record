#!/usr/bin/python
#-*-coding:utf-8-*-

import random,json
from oper import conn,cursor,df,df1

def query(post_str):
        jsonStr=""
        msg=""
        dic_str=json.loads(post_str)
        id=int(dic_str["id"])
        cursor.execute("select rid,s1,n1,s2,n2,s3,n3,s4,n4,s5,n5,s6,n6 from t_blackmarket where rid=%s",(id,))
        result=cursor.fetchone()
        if not result:
                msg=random_shop(id)
		if not len(msg):
			msg="此用户不存在"
			
	else:
		msg=result
        jsonStr=json.dumps({"msg":msg},ensure_ascii=False)
        return jsonStr               	

def random_shop(id):
	insertList=[]
	insertList.append(id)
	flag=True
	i=0
	cursor.execute("select vip,level from t_role where id=%s",(id,))
	role=cursor.fetchone()
	if role:
		vip=role[0]
		level=role[1]
		while flag:
			key=[]
			value=[]
			things=str(df.iloc[:,2].values[i+2])
			list1=things.lstrip().split(";")[0:-1]
			for j in range(len(list1)-2):
				str1=list1[j].split(",")
				key.append(int(str1[0]))
				value.append(int(str1[1]))
			dic=dict(zip(key,value))
			total = sum(dic.values())
			rad = random.randint(1,total)
			cur_total = 0
			res = ""
			for k, v in dic.items():
				cur_total += v
				if rad<= cur_total:
					res = k
					break
			res_index=get_index(res)
			num_limit=0
			vip_limit=10
			level_limit=0
			if vip>=res_index[2] and level>=res_index[3]:
				insertList.append(res_index[0])
				insertList.append(res_index[1])
				i=i+1
			if i==6:
				flag=False
				break
		cursor.execute("insert into t_blackmarket value(null,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",insertList)
		conn.commit()
	else:
		insertList=[]	
	return insertList

def get_index(res):
	num_limit,vip_limit,level_limit,consume=0,0,0,0
	for z in range(2,df1.shape[0]):
		if int(df1.iloc[z:z+1,0:1].values[0][0])==res:
			num_limit=df1.iloc[z:z+1,].values[0][7]
			vip_limit=df1.iloc[z:z+1,].values[0][9]
			level_limit=df1.iloc[z:z+1,].values[0][10]
			consume=df1.iloc[z:z+1,].values[0][3]
	return res,num_limit,vip_limit,level_limit,consume

