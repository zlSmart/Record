#!/usr/bin/python
#-*- coding:utf-8 -*-

from oper import conn,cursor


def register(username,password):
	cursor.execute("select * from t_user where username=%s ",(username,))
        result=cursor.fetchone()
	msg=""
	if not result:
		cursor.execute("insert into t_user value(null,%s,%s)",(username,password,)) 
		conn.commit()
		msg="注册成功!"
	else:
		msg="用户名已存在，注册失败!"
	return msg




def login(username,password):
	cursor.execute("select * from t_user where username=%s ",(username,))
        result=cursor.fetchone()
	if result:
		if str(result[1])==str(username)  and str(result[2])==str(password):
			msg="登录成功！"
		else:
			msg="密码错误！"
	else:
		msg="用户名不存在"
	return msg
	
