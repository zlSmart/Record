#!/usr/bin/python
#-*-coding:utf-8-*-

import linecache
index=0
print len([ "" for line in open("./2018-08-12.log","r")])
f=open('./2018-08-12.log')
for line in f:
	index+=1
print index
f.close()
		


