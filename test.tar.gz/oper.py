#!/usr/bin/python

import time
from time import ctime

def splitFile(fileLocation, targetFoler):
	files = open(fileLocation, 'r')
	num=10000000
	countFile = 0
	i=0
	j=0
	for line in files:
		if i==0:
			countFile = countFile + 1
	#		file_writer = open(targetFoler + 'file_'+str(countFile)+'.txt', 'a+')
	#	file_writer.writelines(line)
		i+=1
		j+=1
		if i==num:
	#		file_writer.close()
			print 'file ' + str(countFile) + ' generated at: '+ str(ctime())
			i=0
	#file_writer.close()
	
	print j
	files.close()
	return countFile
if __name__ == '__main__':
	print 'Start At: ' + str(ctime())
	result=splitFile('./2018-08-12.log', './test/')
	for i in range(result):
		print './test/file_'+str(i+1)+'.txt'
