#!/usr/bin/python
# -*- coding:utf-8-*-


list=[["zhangsan",1,2],["list",2,3],["wangwu",3,4],["zhaoliu",3,4]]
index =0
for i in list:
	index+=1
	if index==len(list):
		print list
print False
