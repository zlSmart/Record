#!/usr/bin/python
# -*- coding:utf-8 -*_

import re


log=open('./2018-08-12.log');
index=0
link=r"([0-9]+)-', <function ([0-9a-zA-Z]+) at"
link2=r"T]', ([0-9][.][0-9]*)"

list=[]
i=j=0
list2=[]
dic={}
try:
	for line in log:
		found1=re.findall(link,line)
		found2=re.findall(link2,line)
		if found1 != None and len(found1) !=0:
			if i-j==0:
				index =index+1
				i+=1;
				list.append(found1)
		if found2 != None and len(found2) !=0:
			if i-j==1:
				index =index+1
				j+=1
				list.append(found2)
		if len(list)==2:
                	dic['ID']=list[0][0][0]
                	dic['f_name']=list[0][0][1]
                	dic['time']=list[1][0]
                	print dic
			del list[0]
			del list[0]
#		if i==j:
#			dic['ID']=list[0][0][0]
#               	dic['f_name']=list[0][0][1]
#	              	dic['time']=list[1][0]
#			print dic
#			del list[0],list[1]
		if index==100:
			break
#	print '-------------------------------------------------------'
#	print list
#	print '-------------------------------------------------------'
#	for i in range(0,len(list),2):
#		dic['ID']=list[i][0][0]
#		dic['f_name']=list[i][0][1]
#		dic['time']=list[i+1][0]
#		print dic
#		list2.append(dic)												
	input()
except:
	pass
