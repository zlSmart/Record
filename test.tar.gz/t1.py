#!/usr/bin/python
# -*- coding:utf-8 -*-

import re
import mysql.connector as con

conn = con.connect(user='root',password='root',database='test1',use_unicode=True)
cursor =conn.cursor()

log=open('./2018-08-12.log')
index=0
l1=r"-([0-9a-z!.]+)-', <function ([0-9a-zA-Z]+)"
l2=r"T]', ([0-9][.][0-9]*)"
l3=r".*Traceback.*"
l4=r".*line [0-9]+, in ([a-zA-Z]+)\\n.*"

list1=[]
i=j=0
dic={}
try:
	for line in log:
		#匹配CallBack结果
		found1=re.findall(l1,line)
		#匹配[T]结果
                found2=re.findall(l2,line)
		#匹配Traceback
		found3=re.findall(l3,line)
                #找到CallBack所在行数
		if found1 != None and len(found1) !=0:
                        if i-j==0:
                                index =index+1
                                i+=1;
                                list1.append(found1)
                #匹配到[T]
		if found2 != None and len(found2) !=0:
                        if i-j==1:
                                index =index+1
                                j+=1
                                list1.append(found2)
		# CallBack和[T]匹配 插入数据库
		if len(list1)==2:
                        dic['ID']=list1[0][0][0]
                        dic['f_name']=list1[0][0][1]
                        dic['time']=list1[1][0]
                        cursor.execute('select * from time where f_name=%s',(dic['f_name'],))
                        value=cursor.fetchall()
                        if not value:
                                cursor.execute('select sum(f_num) FROM time')
                                num=cursor.fetchone()
                                print "CallBack insert"
                                cursor.execute('insert into time (f_name,f_maxtime,f_mintime,f_port,f_num,f_avgtime,f_time) values (%s,%s,%s,%s,%s,%s,%s)',[dic['f_name']
,dic['time'],dic['time'],0,1,dic['time'],dic['time']])
                                conn.commit()
                        else:
                                cursor.execute('select * from time where f_name=%s',(dic['f_name'],))
                                result = cursor.fetchall()
                                r=result[0]
                                cursor.execute('select sum(f_num) FROM time')
                                num=cursor.fetchone()
				list2=[]
                                list2.extend(r)
                                list2[1]=list2[1] if float(list2[1])>float(dic['time']) else dic['time']
                                list2[2]=list2[2] if float(list2[2])<float(dic['time']) else dic['time']
                                list2[4]=list2[4]+1
                                list2[3]=list2[4]/float(num[0])
                                list2[6]+=float(dic['time'])
                             	cursor.execute("update time set f_maxtime=%s,f_mintime=%s,f_port=%s,f_num=%s,f_avgtime=%s,f_time=%s where f_name=%s",(list2[1],list2[2],list2[3],list2[4],list2[5],list2[6],list2[0]))
                                conn.commit()
                                print "CallBack update"
                        del list1[0]
                        del list1[0]
		# 匹配到TraceBack
		if found3!=None and len(found3)!=0:
			print 'TraceBack'
                        found=re.findall(l4,line)
                        if found !=None and len(found)!=0:
                                text=line[30:-3]
                                cursor.execute("select * from error where f_name=%s",(found[0],))
                                value=cursor.fetchall()
				#根据function名查询不到对应数据，将数据插入表中
                                if not value:
                                        if len(text)>5000000:
                                                continue
                                        cursor.execute('insert into error (f_name,f_time,cont) values (%s,%s,%s)',[found[0],1,text])
                                        conn.commit()
                                        print 'Traceback insert'
				#根据function查询到对应数据，对数据进行修改
                                else:
                                        cursor.execute('select * from error where f_name=%s',(found[0],))
                                        result = cursor.fetchone()
                                        list3=[]
					list3.extend(result)
                                        list3[1]+=1
                                        cursor.execute("update error set f_time=%s where f_name=%s",(list3[1],list3[0]))
                                        conn.commit()
                                        print 'Traceback update'
except:
	print 'error'
	
finally:
	cursor.close()
