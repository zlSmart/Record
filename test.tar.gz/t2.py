#!/usr/bin/python
# -*- coding:utf-8 -*-

import re
import mysql.connector as con

log=open('./2018-08-12.log')
l1=r".*Traceback.*"
l2=r".*line [0-9]+, in ([a-zA-Z]+)\\n.*"
list=[]
#index=0
try:
	conn = con.connect(user='root',password='root',database='test1',use_unicode=True)
	cursor =conn.cursor()
	for index,line in log:
		test=re.findall(l1,line)
		if test!=None and len(test)!=0:
			if len(line)>5000000:
				continue
			print index+"----------"+line
			found=re.findall(l2,line)
			if found !=None and len(found)!=0:
#				index+=1
				text=line[30:-3]
				cursor.execute("select * from error where f_name=%s",(found[0],))
				value=cursor.fetchall()
				if not value:
					if len(text)>5000000:
						continue
					cursor.execute('insert into error (f_name,f_time,cont) values (%s,%s,%s)',[found[0],1,text])
                                	conn.commit()
					print 'insert'
				else:
	                                cursor.execute('select * from error where f_name=%s',(found[0],))
                                	result = cursor.fetchone()
					list.extend(result)
					list[1]+=1
					cursor.execute("update error set f_time=%s where f_name=%s",(list[1],list[0]))
	                               	conn.commit()
					print 'update'
	print "success"
except Exception,e:
	print e
finally:
	log.close()
	conn.close()
