#! /usr/bin/env python
# -*-encoding:utf-8-*-

import mysql.connector
import time,threading
	
def oper1(f):
#	conn=mysql.connector.connect(user='root', password='root', database='test1', use_unicode=True)
#	cursor=conn.cursor()
#	str=f.read(1024)
	print 'success1'
	time.sleep(5)
#	print str
	for i in range(10):
		print i
	print 'success11'
#	cursor.close()
def oper2(f):
#	conn=mysql.connector.connect(user='root', password='root', database='test', use_unicode=True)
#	cursor=conn.cursor()
#	str=f.read(1024)
	print 'success2'
	time.sleep(1)
#	print str
#	cursor.close()


f=open('./2018-08-12.log','r')
t1=threading.Thread(target=oper1(f),name='oper1')
t2=threading.Thread(target=oper2(f),name='oper2')

t1.start()
t2.start()
t1.join()
t2.join()
print 'exit'
#f=open('./2018-08-12.log','r')
#while(f.readlines()!=-1):
#	f.read()

#with open('./2018-08-12.log','r') as f:
#	print f.read()
#	for line in f.readlines():
#		print line

