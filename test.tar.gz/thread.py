#!/usr/bin/python
# -*- coding:utf-8 -*-

import re
import threading,time
import mysql.connector as con

def f1(log):
	print 'thread %s is running...' % threading.current_thread().name
	conn = con.connect(user='root',password='root',database='test1',use_unicode=True)
	cursor =conn.cursor()
	index=0
	l1=r"([0-9]+)-', <function ([0-9a-zA-Z]+) at"
	l2=r"T]', ([0-9][.][0-9]*)"
	list=[]
	i=j=0
	dic={}
	try:
		for line in log:
                	found1=re.findall(l1,line)
                	found2=re.findall(l2,line)
                	if found1 != None and len(found1) !=0:
                        	if i-j==0:
                                	index =index+1
                                	i+=1;
                                	list.append(found1)
                	if found2 != None and len(found2) !=0:
                        	if i-j==1:
                                	index =index+1
                                	j+=1
                                	list.append(found2)
                	if len(list)==2:
                        	dic['ID']=list[0][0][0]
                        	dic['f_name']=list[0][0][1]
                        	dic['time']=list[1][0]
                        	cursor.execute('select * from time where f_name=%s',(dic['f_name'],))
                        	value=cursor.fetchall()
                        	if not value:
                                	cursor.execute('select sum(f_num) FROM time')
                                	num=cursor.fetchone()
                                	print "test"
                                	cursor.execute('insert into time (f_name,f_maxtime,f_mintime,f_port,f_num,f_avgtime,f_time) values (%s,%s,%s,%s,%s,%s,%s)',[dic['f_name'],dic['time'],dic['time'],0,1,dic['time'],dic['time']])
                                	conn.commit()
                        	else:
                                	cursor.execute('select * from time where f_name=%s',(dic['f_name'],))
                                	result = cursor.fetchall()
                                	r=result[0]
                                	cursor.execute('select sum(f_num) FROM time')
                                	num=cursor.fetchone()
                                	list2=[]
                                	list2.extend(r)
                                	list2[1]=list2[1] if float(list2[1])>float(dic['time']) else dic['time']
                                	list2[2]=list2[2] if float(list2[2])<float(dic['time']) else dic['time']
                                	list2[4]=list2[4]+1
                                	list2[3]=list2[4]/float(num[0])
                                	list2[6]+=float(dic['time'])
                                	cursor.execute("update time set f_maxtime=%s,f_mintime=%s,f_port=%s,f_num=%s,f_avgtime=%s,f_time=%s where f_name=%s",(list2[1],list2[2],list2[3],list2[4],list2[5],list2[6],list2[0]))
                                	conn.commit()
                                	print "success update"
                        	del list[0]
                        	del list[0]
#               	if index==50:
				
	except:
        	print 'error'

	finally:
        	cursor.close()

def f2(log):
	print 'thread %s is running...' % threading.current_thread().name

log=open('./2018-08-12.log')
t1=threading.Thread(target=f1(log),name='Thread1')
t2=threading.Thread(target=f2(log),name='Thread2')

t1.start()
t2.start()

print 'thread %s ended.' % threading.current_thread().name
