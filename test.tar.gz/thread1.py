#!/usr/bin/python
# -*- coding:utf-8 -*-

import time
from time import ctime
import threading,thread
import re
import mysql.connector as con


#对日志文件按行切割
def splitFile(fileLocation, targetFoler):
	file_handler = open(fileLocation, 'r')
	num=5000000
	countFile = 0
	i=0
	while True:
		line =file_handler.readline()
		if not line:
        	       	break
		countFile = countFile + 1
		file_writer = open(targetFoler + 'file_'+str(countFile)+'.txt', 'a+')
		file_writer.writelines(line)
		while i<num:
			file_writer.writelines(file_handler.readline())
			i+=1
		file_writer.close()
		print 'file ' + str(countFile) + ' generated at: '+ str(ctime())
		i=0
	file_handler.close()
	return countFile
class myThread(threading.Thread):
	def __init__(self, threadName, name,):
		threading.Thread.__init__(self)
		self.threadName = threadName
		self.name = name

	def run(self):
		global lock1,lock2  
		print "Starting " + self.threadName
		index=0
		#正则表达式
		l1=r"-([0-9a-z!.]+)-', <function ([0-9a-zA-Z]+)"
		l2=r"T]', ([0-9][.][0-9]*)"
		l3=r".*Traceback.*"
		l4=r".*line [0-9]+, in ([a-zA-Z]+)\\n.*"
		list1=[]
		t=[]
		callIndex=tIndex=0
		dic={}
		try:
			conn = con.connect(user='root',password='root',database='test1',use_unicode=True)
                	cursor =conn.cursor()
                	log=open(self.name)
			for line in log:
				#匹配CallBack结果
				found1=re.findall(l1,line)
				#匹配[T]结果
				found2=re.findall(l2,line)
				#匹配Traceback
				found3=re.findall(l3,line)
				#找到CallBack所在行数
				if found1 != None and len(found1) !=0:
					if callIndex-tIndex==0:
						index =index+1
						callIndex+=1;
						list1.append(found1)
				#匹配到[T]
				if found2 != None and len(found2) !=0:
					if callIndex-tIndex==1:
						index =index+1
						tIndex+=1
						list1.append(found2)
				# CallBack和[T]匹配 插入数据库
#				if len(list1)==2:
#					dic['ID']=list1[0][0][0]
#					dic['f_name']=list1[0][0][1]
#					dic['time']=list1[1][0]
#					cursor.execute('select * from time where f_name=%s',(dic['f_name'],))
#					value=cursor.fetchall()
#					if not value:
#						lock1.acquire()
#						print self.threadName+"CallBack insert"
#						cursor.execute('select sum(f_num) from time')
#                                              	num1=cursor.fetchone()
#						#function名称冲突则更新
#						cursor.execute('insert into time (f_name,f_maxtime,f_mintime,f_port,f_num,f_avgtime,f_time) values (%s,%s,%s,%s,%s,%s,%s) on duplicate key update f_num = f_num+1,f_time=f_time+%s,f_avgtime=f_time/f_num,f_port=f_num/%s',[dic['f_name'],dic['time'],dic['time'],0,1,dic['time'],dic['time'],dic['time'],num1[0]])
#						conn.commit()
#						lock1.release()
#					else:
#						lock1.acquire()
#						r=value[0]
#						cursor.execute('select sum(f_num) from time')
#						num1=cursor.fetchone()
#						list2=[]
#						list2.extend(r)
#						list2[1]=list2[1] if float(list2[1])>float(dic['time']) else dic['time']
#						list2[2]=list2[2] if float(list2[2])<float(dic['time']) else dic['time']
#						list2[4]=list2[4]+1
#						list2[3]=list2[4]/float(num1[0])
#						list2[6]+=float(dic['time'])
#						cursor.execute("update time set f_maxtime=%s,f_mintime=%s,f_port=%s,f_num=%s,f_avgtime=%s,f_time=%s where f_name=%s",(list2[1],list2[2],list2[3],list2[4],list2[5],list2[6],list2[0]))
#						conn.commit()
#						lock1.release()
#						print self.threadName+"CallBack update"
#					del list1[0]
#					del list1[0]
				insertList=[]
				if len(list1)==100:
					tem=[]
					for l in range(0,len(list1),2):
						li=list(list1[l])
						#           function      ID        time
						tem.append([li[0][1]]+[li[0][0]]+list1[l+1])
					number=0
					flagI=True
					for record in tem:
						li2=["",0.0,0.0,0.0,0,0.0,0,0.0,callIndex]
						if flagI:
							li2[0]=record[0]
							li2[1]=record[2]
							li2[2]=record[2]
							li2[3]=0
							li2[4]=1
							li2[5]=record[2]
							li2[6]=record[2]
							li2[7]=record[2]
							insertList.append(li2)
							flagI=False
						if not flagI:
							flagInsert=0
							for j in insertList:
								if record[0] not in j:
									flagInsert+=1
								if record[0] in j:
									li2[0]=j[0]
									li2[1]=j[1] if j[1]>record[2] else record[2]
									li2[2]=j[2] if j[2]<record[2] else record[2]
									li2[3]=0
									li2[4]=j[4]+1
									li2[6]=round(float(j[6])+float(record[2]),6)
									li2[5]=round(li2[6]/li2[4],6)
									li2[7]=round(float(record[2])+float(j[7]),6)
									insertList.remove(j)
									insertList.append(li2)
								if flagInsert==len(insertList):
									li2[0]=record[0]
                                                        		li2[1]=record[2]
                                                        		li2[2]=record[2]
                                                        		li2[3]=0
                                                        		li2[4]=1
                                                        		li2[5]=record[2]
                                                        		li2[6]=record[2]
									li2[7]=record[2]
									flagInsert=0
                                                        		insertList.append(li2)
									break
					list1=[]
#					cursor.execute('insert into time (f_name,f_maxtime,f_mintime,f_port,f_num,f_avgtime,f_time) values (%s,%s,%s,%s,%s,%s,%s) on duplicate key update f_num = f_num+1,f_time=f_time+%s,f_avgtime=f_time/f_num,f_port=f_num/%s',[dic['f_name'],dic['time'],dic['time'],0,1,dic['time'],dic['time'],dic['time'],num1[0]])
				#	cursor.executemany('insert into time (f_name,f_maxtime,f_mintime,f_port,f_num,f_avgtime,f_time) values (%s,%s,%s,%s,%s,%s,%s) on duplicate key update f_num = f_num+1,f_time=f_time+%s,f_avgtime=f_time/f_num,f_port=f_num/%s',insertList)
                                #       conn.commit()
				# 匹配到TraceBack
				if "Traceback" in line:
					found=re.findall(l4,line)
					if found !=None and len(found)!=0:
						if len(line)>5000000:
                                                	continue
						text=line[30:-3]
						t.append([found[0],1,text,1])
			print t
			lock2.acquire()
			cursor.executemany('insert into error (f_name,f_time,cont) values (%s,%s,%s)on duplicate key update f_time=f_time+%s',t)
			conn.commit()
			lock2.release()
			print 'Exist....'+self.threadName
		except Exception,e:
			print e
			print 'error'
		finally:
			cursor.close()
if __name__ == '__main__':
	print 'Start At: ' + str(ctime())
#	result=splitFile('./2018-08-12.log', './test/')
	lock1 = threading.Lock()
	lock2 = threading.Lock()
	threads = []
	for i in range(3):
		fileName='./test/file_'+str(i+1)+'.txt'
		print fileName
		threads.append(myThread('Thread'+str(i), fileName))
	for t in threads:
		t.start()
	for t in threads:
		t.join()
	print "MainThread Exit..............."
